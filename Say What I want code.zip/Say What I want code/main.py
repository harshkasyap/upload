# coding=utf-8
import logging
logging.basicConfig(level = logging.INFO,format = '%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
import time
import argparse
import torch
import torch.nn as nn
import pickle as pk
from ParlAlSeq2SeqTwitter.reward import compute_reward

parser = argparse.ArgumentParser(description='PyTorch Wikitext-2 Language Model')

# Model parameters.
parser.add_argument('--batch_size', type=int, default=16, metavar='N', help='batch size')
parser.add_argument('--max_message_length', type=int, default=10, metavar='N', help='seqence length')
# parser.add_argument('--pretrained_model', type=str, default='pretrained_model.pt')
parser.add_argument('--outf', type=str, default='generated.txt', help='output file for generated text')
parser.add_argument('--words', type=int, default='1000', help='number of words to generate')
parser.add_argument('--seed', type=int, default=1111, help='random seed')
parser.add_argument('--cuda', action='store_true', help='use CUDA')
parser.add_argument('--temperature', type=float, default=1.0, help='temperature - higher will increase diversity')
parser.add_argument('--log-interval', type=int, default=100, help='reporting interval')
parser.add_argument('--clip', type=float, default=0.25, help='gradient clipping')
parser.add_argument('--score_type', type=str, default="bleu", help='gradient clipping')
parser.add_argument('--target', type=str, default="data/train.txt", help='gradient clipping')
parser.add_argument('--max_response_len', type=int, default=20)
args = parser.parse_args()

# Set the random seed manually for reproducibility.
torch.manual_seed(args.seed)
if torch.cuda.is_available():
    if not args.cuda:
        print("WARNING: You have a CUDA device, so you should probably run with --cuda")

device = torch.device("cuda" if args.cuda else "cpu")
# device = torch.device("cpu")

if args.temperature < 1e-3:
    parser.error("--temperature has to be greater or equal 1e-3")

with open("data/dict.pkl", 'rb') as f:
    dict = pk.load(f)
    logger.info("Dictionary Loaded.")

with open(args.target, 'r', encoding='utf-8') as f:
    target_list = f.read().split('\n')
    target_list = [line.split('\t')[0] for line in target_list]

def batchify(data, bsz):
    # Work out how cleanly we can divide the dataset into bsz parts.
    ntenbatch = len(data) // (bsz * 10)
    batchdata = []
    for i in range(ntenbatch):
        tenbatch = data[i * (bsz * 10):(i + 1) * (bsz * 10)]
        sorted_tenbatch = sorted(tenbatch, key=lambda d: len(d.split()), reverse=True) # decreasing order
        for j in range(10):
            batchdata.append(sorted_tenbatch[j * bsz : (j + 1) * bsz])

    return batchdata

def index_and_pad(batch, max_res_len, pad_idx):
    batch_idx = [[dict.word2idx.get(word, dict.word2idx['<unk>']) for word in sample.split()] for sample in batch]
    res_len = max([len(sample) for sample in batch_idx])
    if res_len > max_res_len:
        res_len = max_res_len

    assert pad_idx == 0
    xs = []
    for sample in batch_idx:
        res = sample[:res_len]
        xs.append(res + [pad_idx] * (res_len - len(res)))
    xs = torch.tensor(xs)

    return xs.to(device)

nepoch = 20000
ntokens = len(dict)
go_token = dict.word2idx['<go>']
eos_token = dict.word2idx['<eos>']
logger.info("go_token: {}".format(go_token))
logger.info("eos_token: {}".format(eos_token))
batch_size = args.batch_size
max_message_length = args.max_message_length
score_type = args.score_type
padding_weights = torch.ones(ntokens).to(device)
padding_weights[dict.word2idx['<pad>']] = 0
CrossEntropyLoss = nn.CrossEntropyLoss(reduce=False, weight=padding_weights)

with open(args.pretrained_model, 'rb') as f:
    model = torch.load(f, map_location="cpu").to(device)
    model.drop = nn.Dropout(0.0)
    logger.info("Pre-trained Model Loaded.")

def get_sample_mask_and_length(samples):
    samples_tensor = torch.stack(samples, 0) # samples_tensor: (seq_length x batch_size)
    samples_tensor_t = samples_tensor.transpose(0, 1) # samples_tensor_t: (batch_size x seq_length)
    lengths = []
    for sample in samples_tensor_t:
        eos_pos = [pos for pos in range(len(sample)) if sample[pos] == eos_token]
        if len(eos_pos) == 0:
            length = len(sample)
        else:
            length = eos_pos[0] + 1 # No problem
        lengths.append(length)
    mask = torch.zeros_like(samples_tensor, dtype=torch.float32) # mask: (seq_length x batch_size)
    for i, length in enumerate(lengths):
        for t in range(length):
            mask[t][i] = 1.0
    mask = torch.transpose(mask, 0, 1) # mask: (batch_size x seq_length)
    return mask, lengths

traindata = batchify(target_list, bsz=batch_size)

with open('data/test/twitter_generated_targets_1_3.txt', 'r') as f:
    test_target_list = f.read().split('\n')
logger.info("Test data loaded.")
testdata = batchify(test_target_list, bsz=1)

def test(testdata):
    # Turn on training mode which enables dropout.
    model.eval()
    start_time = time.time()
    success_05 = 0
    success_06 = 0
    success_07 = 0
    success_08 = 0
    success_09 = 0
    total_reward = 0

    for i, batch in enumerate(testdata):
        xs = index_and_pad(batch, max_res_len=args.max_response_len, pad_idx=dict.word2idx['<pad>']) # (batch_size x seq_len)

        preds, enc_hidden = model.forward(xs, max_message_length=max_message_length) # samples: list (seq_length x batch_size)
        preds = preds[0]
        wordlist = []
        for index in preds:
            word = dict.idx2word[index]
            if word != '<eos>':
                wordlist.append(word)
            else:
                break
        message = ' '.join(wordlist)

        rewards, _ = compute_reward(samples=[message], targets=batch, type=args.score_type, test=True)

        reward = rewards[0]

        if reward >= 0.9:
            success_09 += 1
            success_08 += 1
            success_07 += 1
            success_06 += 1
            success_05 += 1
        elif reward >= 0.8:
            success_08 += 1
            success_07 += 1
            success_06 += 1
            success_05 += 1
        elif reward >= 0.7:
            success_07 += 1
            success_06 += 1
            success_05 += 1
        elif reward >= 0.6:
            success_06 += 1
            success_05 += 1
        elif reward >= 0.5:
            success_05 += 1

        total_reward += reward

        elapsed = time.time() - start_time
        logger.info('| {:5d}/{:5d} instances | ms/batch {:5.2f} | '.format(i, len(testdata), elapsed * 1000))
        start_time = time.time()

    logger.info("Instances: {}".format(len(testdata)))
    logger.info("Average Score : {}".format(total_reward / len(testdata)))
    logger.info("Success Rate >= 0.5: {}".format(success_05 / len(testdata)))
    logger.info("Success Rate >= 0.6: {}".format(success_06 / len(testdata)))
    logger.info("Success Rate >= 0.7: {}".format(success_07 / len(testdata)))
    logger.info("Success Rate >= 0.8: {}".format(success_08 / len(testdata)))
    logger.info("Success Rate >= 0.9: {}".format(success_09 / len(testdata)))

def del_eos(string):
    wordlist = []
    for word in string.split():
        if word != '<eos>':
            wordlist.append(word)
        else:
            break

    return ' '.join(wordlist)

for epoch in range(nepoch):
    for i, batch in enumerate(traindata):
        xs = index_and_pad(batch, max_res_len=args.max_response_len,
                           pad_idx=dict.word2idx['<pad>'])  # (batch_size x seq_len)

        pars = model.parameters()
        optimizer = torch.optim.Adam(pars, lr=0.001)

        model.eval()
        samples, enc_hidden = model.sample(xs, max_message_length)  # samples: list (seq_length x batch_size)
        sample_texts = [del_eos(' '.join([dict.idx2word[w] for w in sample])) for sample in
                        torch.transpose(torch.stack(samples, 0), 0, 1)]
        ys = torch.transpose(torch.stack(samples, 0), 0, 1)  # ys: (batch_size x seq_length)

        # Train the generator for one step
        model.train()
        optimizer.zero_grad()
        _, scores = model(xs, ys)  # scores: (batch_size x seq_len x ntokens)
        mask, lengths = get_sample_mask_and_length(
            samples)  # lengths: list (batch_size) # mask: (batch_size x seq_length)
        mask = mask.to(device)  # mask: (seq_length x batch_size)
        rewards, predictions = compute_reward(samples=sample_texts, targets=batch,
                                              type=args.score_type)  # rewards: (batch_size)
        rewards = rewards.to(device)

        EntropyLoss = CrossEntropyLoss(scores.contiguous().view(-1, ntokens),
                                       ys.contiguous().view(-1)) * mask.contiguous().view(-1)
        loss = torch.sum(
            EntropyLoss.contiguous().view(mask.size()[0], mask.size()[1]) * rewards.contiguous().view(-1, 1))
        loss.backward()
        logger.info(
            "Epoch : {}  Batch: {} / {}  Batch Size: {}  Loss: {}".format(epoch + 1, i, len(traindata), batch_size,
                                                                          loss))
        if i % 10 == 0:
            logger.info("Rewards: {}".format(rewards))
            logger.info("Samples: {}".format(sample_texts))
            logger.info("Targets: {}".format(batch))

        # `clip_grad_norm` helps prevent the exploding gradient problem in RNNs / LSTMs.
        torch.nn.utils.clip_grad_norm_(pars, args.clip)
        optimizer.step()

        if i % 200 == 0:
            test(testdata)

        if i % 200 == 0 and i > 0:
            with open("RDG_model.pt", 'wb') as f:
                torch.save(model, f)
                logger.info("Model saved to " + "RDG_model.pt")