from nltk.translate.bleu_score import sentence_bleu
import numpy as np

def calculate_bleu(reference_sentence, candidate_sentence):
  # reference_sentence = reference_sentence.decode()
  # candidate_sentence = candidate_sentence.decode()

  reference_sentence = reference_sentence
  candidate_sentence = candidate_sentence

  reference = [reference_sentence.split()]
  candidate = candidate_sentence.split()

  score1 = sentence_bleu(reference, candidate, weights=(1.0,))
  score2 = sentence_bleu(reference, candidate, weights=(0.5, 0.5))
  score = (score1 + score2) / 2

  score = np.float32(score).astype(np.float32)

  return score